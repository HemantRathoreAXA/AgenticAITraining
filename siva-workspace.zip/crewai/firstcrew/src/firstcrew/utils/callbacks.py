from crewai.tasks.task_output import TaskOutput
import threading
from datetime import datetime


def create_task_callback(task_name: str):

    def mytaskcallback(task_output: TaskOutput):
    

        log_entry = {
            "thread_name": threading.current_thread().name,
            "task_name": task_name,
            "timestamp": datetime.now().isoformat(), 
            "output": task_output.raw[:200] + "..." if len(task_output.raw) > 200 else task_output.raw
        }

        print(log_entry)
        
    return mytaskcallback