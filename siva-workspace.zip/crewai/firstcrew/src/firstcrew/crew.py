from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai.agents.agent_builder.base_agent import BaseAgent
from typing import List

from firstcrew.tools.custom_tool import CustomerInfoTool
from crewai_tools import SerperDevTool
from firstcrew.utils.callbacks import create_task_callback


@CrewBase
class Firstcrew():
    """Firstcrew crew"""

    agents: List[BaseAgent]
    tasks: List[Task]

    @agent
    def financial_advisor(self) -> Agent:
        return Agent(
            config=self.agents_config['financial_advisor'], # type: ignore[index]
          #  tools=[CustomerInfoTool(), SerperDevTool()],
            verbose=True
        )
    
    @agent
    def tax_advisor(self) -> Agent:
        """Tax planning specialist agent."""
        return Agent(
            config=self.agents_config['tax_advisor'],
            verbose=True
        )

    @agent
    def retirement_advisor(self) -> Agent:
        """Retirement planning specialist agent."""
        return Agent(
            config=self.agents_config['retirement_advisor'],
            verbose=True
        )

    @agent
    def strategy_aggregator(self) -> Agent:
        """Strategy integration and aggregation agent."""
        return Agent(
            config=self.agents_config['strategy_aggregator'],
            verbose=True
        )

    @task
    def financial_analysis_task(self) -> Task:
        return Task(
            config=self.tasks_config['financial_analysis_task'], # type: ignore[index]
            output_file='financial_analysis_report.md',
            tools=[CustomerInfoTool()],
            callback=create_task_callback("financial_analysis_task")

        )
    @task
    def investment_planning_task(self) -> Task:
        return Task(
            config=self.tasks_config['investment_planning_task'], # type: ignore[index]
            tools=[SerperDevTool()],
            output_file='investment_recommendations.md',
            callback=create_task_callback("investment_planning_task"),
            context= [self.financial_analysis_task()]
        )
    
    @task
    def retirement_planning_task(self) -> Task:
        return Task(
            config=self.tasks_config['retirement_planning_task'], # type: ignore[index]
            output_file='retirement_planning_report.md',
            callback=create_task_callback("retirement_planning_task"),
            context= [self.financial_analysis_task(), self.investment_planning_task()],
            async_execution=True
        )

    @task
    def tax_planning_task(self) -> Task:
        return Task(
            config=self.tasks_config['tax_planning_task'], # type: ignore[index]
            output_file='tax_planning_report.md',
            callback=create_task_callback("tax_planning_task"),
            context= [self.financial_analysis_task(), self.investment_planning_task()],
            async_execution=True
        )

    @task
    def strategy_aggregation_task(self) -> Task:
        return Task(
            config=self.tasks_config['strategy_aggregation_task'], # type: ignore[index]
            output_file='comprehensive_strategy.md',
            callback=create_task_callback("strategy_aggregation_task"),
            context= [self.financial_analysis_task(), self.investment_planning_task(),
                      self.retirement_planning_task(), self.tax_planning_task()]
        )

    @crew
    def crew(self) -> Crew:
        """Creates the Firstcrew crew"""
     

        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.hierarchical,
            verbose=True,
            manager_llm="gpt-4",
            # process=Process.hierarchical, # In case you wanna use that instead https://docs.crewai.com/how-to/Hierarchical/
        )
