#!/usr/bin/env python
import sys
import warnings

from datetime import datetime

# Must precede any llm module imports

from langtrace_python_sdk import langtrace

langtrace.init(api_key = 'aac9fef827a339a46d74bb5a92a82bafcf69d5905e0f8896006c3a1e29c29056')

from firstcrew.crew import Firstcrew

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

# This main file is intended to be a way for you to run your
# crew locally, so refrain from adding unnecessary logic into this file.
# Replace with inputs you want to test with, it will automatically
# interpolate any tasks and agents information

def run():
    """
    Run the crew.
    """
    inputs = {
        "customer_id": 1,
    }
    try:
        Firstcrew().crew().kickoff(inputs=inputs)
    except Exception as e:
        raise Exception(f"An error occurred while running the crew: {e}")
