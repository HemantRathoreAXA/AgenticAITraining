import asyncio
from pathlib import Path
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


BASE_DIR = Path(__file__).parent
server_params = StdioServerParameters(
    command="python",
    args=[str(BASE_DIR / "McpPromptsServer.py")],
    cwd=str(BASE_DIR),
  )


async def run() -> None:

    async with stdio_client(server_params) as (read, write):
      async with ClientSession(read, write) as session:
        print("Initializing MCP session for prompt + resource demo...")
        await session.initialize()

        result = await session.get_prompt("orders_summary", {"include_weather": "true"})

        print(result.messages)

        # resources = await session.list_resources()
        # for res in resources.resources:
        #   mime = res.mimeType or "text/plain"
        #   desc = res.description or "(no description)"
        #   print(f"- {res.uri} ({mime}): {desc}")



        # prompts = await session.list_prompts()

        # for prompt in prompts.prompts:
        #   arg_str = ", ".join(
        #     f"{arg.name}{' (required)' if arg.required else ''}"
        #     for arg in (prompt.arguments or [])
        #   ) or "(no args)"
        #   print(f"- {prompt.name}: {prompt.description or '(no description)'} | args: {arg_str}")


if __name__ == "__main__":
    asyncio.run(run())