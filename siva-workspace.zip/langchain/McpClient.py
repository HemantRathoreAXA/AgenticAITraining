from mcp import StdioServerParameters,ClientSession
from mcp.client.stdio import stdio_client
from mcp.client.sse import sse_client
from mcp.client.streamable_http import streamable_http_client



async def main():
    # server_params = StdioServerParameters(
    #                 command="python",
    #                 args=["FileSystemMcpServer.py"]
    #             )


    async with streamable_http_client("http://localhost:8000/mcp") as (read,write,_):
        async with ClientSession(read, write) as session:

           await  session.initialize()

           result=await session.call_tool("list_tables", {"db_path": "C:\\database\\fintech.db"})
           for content in result.content:
               print(content.text)

        #    tools= await session.list_tools()

        #    for tool in tools.tools:
        #        print(f"Tool: {tool.name}, Description: {tool.description}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
