from langchain_mcp_adapters.client import MultiServerMCPClient 
from langchain.agents import create_agent 
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
load_dotenv()


async def main():

    client = MultiServerMCPClient(
       {
        "fsserver": {
            "transport": "stdio",  # Local subprocess communication
            "command": "python",
            # Absolute path to your math_server.py file
            "args": ["FileSystemMcpServer.py"],
        },
        "dbserver": {
            "transport": "http",  # HTTP-based remote server
            # Ensure you start your weather server on port 8000
            "url": "http://localhost:8000/mcp",
        }
    }
    )

    tools= await client.get_tools()

    agent= create_agent(
        tools=tools,
       model= ChatOpenAI(model="gpt-4.1-mini")
    )

    result= await agent.ainvoke(
        {
            "messages" : [
                {
                    "role": "user",
                    "content": "list all tables in the database located at 'C:\\database\\fintech.db'."
                }
            ]
        }
    )

    print(result['messages'][-1].content)


   


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())