import os
from typing import List

# LangChain 1.x imports - using the modern approach
from langchain.agents import create_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# Import existing LangChain community Gmail tools
from langchain_community.tools.gmail import GmailSendMessage

# Google API imports
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import pickle
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langgraph.checkpoint.memory import InMemorySaver
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


def get_gmail_service():
    """Creates Gmail service with proper authentication for sending emails"""
    # We need the send scope to send emails
    SCOPES = ['https://www.googleapis.com/auth/gmail.send']
    creds = None

    # The file token.pickle stores the user's access and refresh tokens
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If there are no (valid) credentials available, let the user log in
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            # Refresh the credentials
            creds.refresh(Request())
        else:
            # Create new credentials
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    # Build and return the Gmail service
    return build('gmail', 'v1', credentials=creds)

print("✅ Gmail authentication function created!")
print("📧 This will authenticate for email sending permissions")

if __name__ == "__main__":
    service = get_gmail_service()
  