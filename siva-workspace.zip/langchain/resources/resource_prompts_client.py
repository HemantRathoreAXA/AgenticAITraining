"""
Client demo:
- Lists dynamic resources (orders + weather) exposed by the server.
- Lists prompts exposed via @mcp.prompt.
- Fetches prompts (including embedded resources) with get_prompt.

Run with: python resource_prompts_client.py
"""

import asyncio
from pathlib import Path
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

BASE_DIR = Path(__file__).parent
server_params = StdioServerParameters(
    command="python",
    args=[str(BASE_DIR / "resource_prompts_server.py")],
    cwd=str(BASE_DIR),
)


def _content_to_text(content: Any) -> str:
    if getattr(content, "text", None):
        return content.text

    resource = getattr(content, "resource", None)
    if resource:
        res_uri = getattr(resource, "uri", "(no uri)")
        res_text = getattr(resource, "text", None)
        if res_text:
            return f"[embedded resource: {res_uri}]\n{res_text}"
        blob = getattr(resource, "blob", None)
        if blob:
            return f"[embedded binary resource: {res_uri}] ({len(blob)} base64 chars)"

    return str(content)


async def print_prompt(session: ClientSession, name: str, arguments: dict | None = None) -> None:
    result = await session.get_prompt(name, arguments)
    desc = result.description or "(no description)"
    print(f"\nPrompt '{name}': {desc}")
    for idx, msg in enumerate(result.messages, start=1):
        content_text = _content_to_text(msg.content)
        print(f" {idx}. {msg.role}: {content_text}")


async def run() -> None:
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            print("Initializing MCP session for prompt + resource demo...")
            await session.initialize()

            resources = await session.list_resources()
            print("\nDiscovered dynamic resources:")
            for res in resources.resources:
                mime = res.mimeType or "text/plain"
                desc = res.description or "(no description)"
                print(f"- {res.uri} ({mime}): {desc}")

            print("\nSample read of live weather resource:")
            weather = await session.read_resource("res:data/weather")
            weather_text = getattr(weather.contents[0], "text", "")
            print(weather_text)

            prompts = await session.list_prompts()
            print("\nDiscovered prompts:")
            for prompt in prompts.prompts:
                arg_str = ", ".join(
                    f"{arg.name}{' (required)' if arg.required else ''}"
                    for arg in (prompt.arguments or [])
                ) or "(no args)"
                print(f"- {prompt.name}: {prompt.description or '(no description)'} | args: {arg_str}")

            await print_prompt(session, "welcome", {"user_name": "Sky"})
            await print_prompt(session, "orders_summary", {"include_weather": "true"})
            await print_prompt(session, "weather_brief", {"city": "Seattle"})
            await print_prompt(session, "order_and_weather_update", {"city": "Seattle"})


if __name__ == "__main__":
    asyncio.run(run())
