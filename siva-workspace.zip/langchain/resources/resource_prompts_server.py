"""
MCP server demonstrating:
- Resources for dynamic data (orders + weather).
- Prompts exposed with @mcp.prompt (not @mcp.resource).
- Prompts that embed dynamic resources so clients see live context.
"""

import json
from pathlib import Path
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.prompts.base import AssistantMessage, UserMessage
from mcp.types import EmbeddedResource, TextResourceContents

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"

# In-memory data; replace with DB queries in a real system.
ORDERS = [
    {"id": 2001, "item": "Mechanical keyboard", "status": "processing"},
    {"id": 2002, "item": "Monitor arm", "status": "shipped"},
    {"id": 2003, "item": "Webcam", "status": "delivered"},
]

mcp = FastMCP("prompt-resources")


def _orders_table() -> str:
    lines = ["id\titem\tstatus"]
    for o in ORDERS:
        lines.append(f"{o['id']}\t{o['item']}\t{o['status']}")
    return "\n".join(lines)


def _weather_snippet(city_override: str | None = None) -> str:
    path = DATA_DIR / "weather.json"
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        today = data.get("date", "today")
        city = city_override or data.get("city", "your city")
        forecast = ", ".join(f"{p['period']}: {p['conditions']} {p['temp_c']}C" for p in data.get("forecast", []))
        return f"Weather for {city} on {today}: {forecast}"
    city = city_override or "your city"
    return f"Weather data unavailable for {city}"


def _embed_resource(uri: str, text: str) -> EmbeddedResource:
    """Create an EmbeddedResource payload for prompt messages."""
    return EmbeddedResource(
        type="resource",
        resource=TextResourceContents(uri=uri, text=text),
    )


@mcp.resource("res:data/orders", name="Orders (TSV)", description="Latest order table", mime_type="text/tab-separated-values")
def resource_orders() -> str:
    return _orders_table()


@mcp.resource("res:data/weather", name="Weather snapshot", description="Today\'s weather summary")
def resource_weather_default() -> str:
    return _weather_snippet()


@mcp.resource("res:data/weather/{city}", name="Weather by city", description="Weather with city override")
def resource_weather_by_city(city: str) -> str:
    return _weather_snippet(city)


@mcp.prompt("welcome", description="Greets the user and offers help with orders or weather.")
def prompt_welcome(user_name: str | None = None) -> list[AssistantMessage | UserMessage]:
    greeting = f"Hi {user_name}!" if user_name else "Hi there!"
    return [
        AssistantMessage(
            "You are a concise assistant. Greet the user and offer help with orders or weather. Avoid long responses."
        ),
        UserMessage(f"{greeting} Let me know if you need order or weather updates."),
    ]


@mcp.prompt("orders_summary", description="Summarize current orders; can optionally pull weather too.")
def prompt_orders_summary(include_weather: str | None = "true") -> list[AssistantMessage | UserMessage]:
    messages: list[AssistantMessage | UserMessage] = [
        AssistantMessage(
            "You are an operations assistant. Summarize the current orders using the embedded table."
        ),
        UserMessage(_embed_resource("res:data/orders", _orders_table())),
    ]

    if str(include_weather or "true").strip().lower() in {"1", "true", "yes", "y", "on"}:
        messages.append(
            UserMessage(
                _embed_resource("res:data/weather", _weather_snippet())
            )
        )

    messages.append(
        UserMessage(
            "Return one sentence with counts per status and include weather if present. Keep it crisp."
        )
    )
    return messages


@mcp.prompt("weather_brief", description="Two-sentence weather brief; optionally override city.")
def prompt_weather_brief(city: str | None = None) -> list[AssistantMessage | UserMessage]:
    weather_uri = f"res:data/weather/{city}" if city else "res:data/weather"
    return [
        AssistantMessage("You are a concise meteorologist. Write a 2-sentence brief."),
        UserMessage(_embed_resource(weather_uri, _weather_snippet(city))),
    ]


@mcp.prompt("order_and_weather_update", description="Combined order + weather update under 80 words.")
def prompt_order_and_weather(city: str | None = None) -> list[AssistantMessage | UserMessage]:
    weather_uri = f"res:data/weather/{city}" if city else "res:data/weather"
    return [
        AssistantMessage(
            "You are an ops assistant. Deliver a single, friendly update with orders and weather in under 80 words."
        ),
        UserMessage(_embed_resource("res:data/orders", _orders_table())),
        UserMessage(_embed_resource(weather_uri, _weather_snippet(city))),
    ]


if __name__ == "__main__":
    mcp.run()
