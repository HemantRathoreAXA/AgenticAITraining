"""
MCP server illustrating how resource exposure differs from a REST API.
- No HTTP routes or hosts. Resources are logical URIs resolved by the server.
- Discovery is built in via list_resources; clients do not need out-of-band docs.
"""

import json
from pathlib import Path
from mcp.server.fastmcp import FastMCP

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
ORDERS = json.loads((DATA_DIR / "orders.json").read_text(encoding="utf-8"))

mcp = FastMCP("resource-vs-rest")


@mcp.resource("res:orders")
def orders_index() -> str:
    """Return a summary list of orders (logical resource, not an HTTP collection)."""
    return json.dumps(ORDERS["orders"], indent=2)


@mcp.resource("res:orders/{order_id}")
def order_detail(order_id: str) -> str:
    """Return a single order. In REST this would be GET /orders/{id}, here it's in-band."""
    match = next((o for o in ORDERS["orders"] if str(o["id"]) == str(order_id)), None)
    if not match:
        return json.dumps({"error": "order not found", "id": order_id}, indent=2)
    return json.dumps(match, indent=2)


@mcp.resource("res:explain-diff")
def explain_diff() -> str:
    """Narrates how MCP resources differ from REST endpoints."""
    return (
        "MCP resources are discovered and delivered over the same session; "
        "there are no HTTP routes, hosts, or auth headers per call. The client "
        "asks list_resources, learns URIs like res:orders/1001, and reads them. "
        "REST needs external docs or OpenAPI, plus network transport for each request."
    )


if __name__ == "__main__":
    mcp.run()
