"""
Client that consumes MCP resources from resource_server.py.
Run with: python resource_client.py
"""

import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

server_params = StdioServerParameters(
    command="python",
    args=["resource_server.py"],
)


async def run() -> None:
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            print("Initializing session over MCP (stdio transport)...")
            await session.initialize()

            resources = await session.list_resources()
            print("Resources exposed by the server:")
            for res in resources.resources:
                mime = res.mimeType or "text/plain"
                desc = res.description or "(no description)"
                print(f"- {res.uri} ({mime}): {desc}")

            print("\nManual reads (uncomment the loop below to test listing + reading):")

            # for res in resources.resources:
            #     result = await session.read_resource(res.uri)
            #     first = result.contents[0]
            #     text = getattr(first, "text", "")
            #     print(f"[loop] {res.uri}: {text}\n")

            for uri in ("res:welcome", "res:weather", "res:motd"):
                result = await session.read_resource(uri)
                first = result.contents[0]
                text = getattr(first, "text", "")
                print(f"{uri}: {text}\n")


if __name__ == "__main__":
    asyncio.run(run())
