"""
Client that contrasts MCP resource consumption with typical REST thinking.
Run with: python resource_vs_rest_client.py
"""

import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

server_params = StdioServerParameters(command="python", args=["resource_vs_rest_server.py"])


async def run() -> None:
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            print("Initializing MCP session (no HTTP endpoints involved)...")
            await session.initialize()

            print("\nDiscovered resources via list_resources (like a built-in directory):")
            resources = await session.list_resources()
            for res in resources.resources:
                print(f"- {res.uri} | mime={res.mimeType} | desc={res.description}")

            print("\nReading resources explicitly (contrast with REST URLs):")
            for uri in ("res:orders", "res:orders/1002", "res:explain-diff"):
                result = await session.read_resource(uri)
                first = result.contents[0]
                text = getattr(first, "text", "")
                print(f"{uri}:\n{text}\n")

            print("\nWhat would this look like with REST? You'd do something like:")
            print("GET https://api.example.com/orders -> requires host, route, headers")
            print("GET https://api.example.com/orders/1002 -> separate HTTP call")
            print("Docs served separately (OpenAPI/Swagger) instead of list_resources")


if __name__ == "__main__":
    asyncio.run(run())
