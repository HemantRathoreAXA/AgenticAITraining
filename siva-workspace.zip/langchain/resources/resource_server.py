"""
Minimal MCP server exposing resources via the FastMCP decorator API.
Pair with resource_client.py for a working demo.
"""

from pathlib import Path
from mcp.server.fastmcp import FastMCP

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"

mcp = FastMCP("resource-demo")


@mcp.resource("res:welcome")
def welcome() -> str:
    return (
        "Hello from MCP resources. "
        "This content is streamed over the MCP connection, not fetched via HTTP."
    )


@mcp.resource("res:weather")
def weather() -> str:
    return (DATA_DIR / "weather.json").read_text(encoding="utf-8")


@mcp.resource("res:motd")
def motd() -> str:
    """Example of adding a resource with the decorator API."""
    return "Message of the day: use resources for in-band data, no HTTP needed."


if __name__ == "__main__":
    mcp.run()
