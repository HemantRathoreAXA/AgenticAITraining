# MCP resource demo

A minimal example that defines two MCP resources on a server and consumes them from a client. It contrasts how MCP resources differ from a traditional REST API.

## Files
- resource_server.py — MCP server using `@mcp.resource` to expose resources (`res:welcome`, `res:weather`, `res:motd`).
- resource_client.py — MCP client that discovers and reads those resources.
- data/weather.json — sample payload the server returns for `res:weather`.
- resource_vs_rest_server.py — MCP server exposing logical resources (`res:orders`, `res:orders/{id}`, `res:explain-diff}`) to contrast with REST.
- resource_vs_rest_client.py — client that lists those resources, reads them, and shows what the REST equivalents would look like.
- data/orders.json — sample data backing the orders resources.
- resource_prompts_server.py — MCP server exposing prompts as resources, composed with live in-memory data and local weather file.
- resource_prompts_client.py — client that lists those prompt resources and reads them explicitly.

## How this differs from REST
- **Discovery is built in:** Clients call `list_resources` to get the available URIs, names, descriptions, and MIME types. REST clients need separate docs or OpenAPI to know what exists.
- **Transport-agnostic delivery:** The resource content streams over the same bidirectional MCP session (stdio here). No HTTP endpoint, routing, or CORS to manage.
- **Stable resource identity:** URIs like `res:welcome` are logical names, not network locations. The server decides how to fulfill them (in-memory string, local file, DB row, etc.).
- **Typed contents:** Each resource advertises `mimeType`, so the client knows how to parse it without guessing. REST often relies on out-of-band knowledge or `Content-Type` headers per request.
- **Single initialization:** Authentication/handshake happens once during `initialize`; reading multiple resources does not repeat auth headers or round-trips like individual REST calls would.

## Run it
```bash
cd 12-mcp/resources
python -m pip install "mcp>=0.1.0" anyio
python resource_client.py

# Resource-vs-REST demo
python resource_vs_rest_client.py

# Prompt resources demo
python resource_prompts_client.py
```
The client launches the server over stdio, calls `list_resources`, prints the metadata, then reads each resource and prints the contents.

## Extending
- Add another entry in `list_resources()` in resource_server.py and handle it in `read_resource()`.
- Swap transports (e.g., SSE or WebSocket) by replacing `stdio_server`/`stdio_client` with the appropriate transport helpers from the MCP library—no REST routing changes required.
