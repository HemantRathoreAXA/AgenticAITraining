from mcp.server.fastmcp import FastMCP
from pathlib import Path
from typing import List

mcp= FastMCP("SivaFsServer")


@mcp.tool()
def list_files(directory: str) -> List:
    """List all files in the given directory."""

    return [f.absolute() for f in Path(directory).iterdir() if f.is_file()]


@mcp.tool()
def create_directory(directory: str) -> str:
    """Create a new directory"""
    try:
        Path(directory).mkdir(parents=True, exist_ok=True)
        return "Directory created successfully"
    except Exception as e:
        return f"Error: {str(e)}"
    

@mcp.tool()

def delete_file(file_path: str) -> str:
    """Delete a file"""
    try:
        Path(file_path).unlink()
        return "File deleted successfully"
    except Exception as e:
        return f"Error: {str(e)}"
    

if __name__ == "__main__":
    mcp.run("stdio")